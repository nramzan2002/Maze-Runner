package Maze_DS;

import DataStructures.EmptyCollectionException;
import DataStructures.StackADT;
import java.util.ArrayList;

/**
 *
 * @author Noor Ramzan
 * @param <T>
 */
//implementing all abstract methods 
public class ArrayListStack<T> implements StackADT<T>{
    private ArrayList<T> stacks;
    private int numOfStacks;
/**
 * ArrayListStack 
 * 
 */
    public ArrayListStack(){
        stacks = new ArrayList<>();
        numOfStacks = 0;
    }
    /*
    *
    *@param push
    */
    @Override
    public void push(T element) {
        stacks.add(element); 
    }
    /*
    *
    * @param pop
    * @throw exception 
    */
    @Override
    public T pop() throws EmptyCollectionException {
        if(isEmpty()){
            throw new EmptyCollectionException("The Stack is Empty");
        }
        return stacks.remove(stacks.size()-1);
    }
    /*
    *
    * @param peek
    * @throw exception 
    */
    @Override
    public T peek() throws EmptyCollectionException {
        if(isEmpty()){
            throw new EmptyCollectionException("The Stack is Empty"); 
        }
        return stacks.get(stacks.size()-1);
    }
    /*
    *
    * @param isEmpty 
    */
    @Override
    public boolean isEmpty() {
        return stacks.isEmpty(); 
    }
    @Override
    public int size() {
        return stacks.size();
    }
    /*
    *
    * @param toString
    * return stacks, numOfStacks
    */
    @Override
    public String toString() {
        return "ArrayListStack{" + "stacks=" + stacks + ", numOfStacks=" + numOfStacks + '}';
    }
        
}